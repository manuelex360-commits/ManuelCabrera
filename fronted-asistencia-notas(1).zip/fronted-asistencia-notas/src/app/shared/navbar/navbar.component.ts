import { Component } from '@angular/core';
import { RouterLinkActive, RouterOutlet, RouterLinkWithHref } from '@angular/router';

@Component({
  selector: 'app-navbar',
  imports: [RouterLinkActive, RouterOutlet, RouterLinkWithHref],
  templateUrl: './navbar.component.html'
})
export class NavbarComponent {}
