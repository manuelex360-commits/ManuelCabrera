import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-cursos',
  templateUrl: './cursos.comonent.html',
})
export class Cursos {}
