import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-matriculas',
  templateUrl: './matriculas.component.html',
})
export class Matriculas {}
