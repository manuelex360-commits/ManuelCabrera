import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-profesores',

  templateUrl: './profesores.component.html',
})
export class Profesores {}
