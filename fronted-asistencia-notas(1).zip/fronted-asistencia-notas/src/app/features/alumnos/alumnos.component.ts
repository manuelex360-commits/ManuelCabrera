import { Component, OnInit } from '@angular/core';
import { AlumnoService } from '../../core/services/alumno.service';
import { Alumno } from '../../core/models/alumno.model';

@Component({
  imports: [],
  selector: 'app-alumnos',
  templateUrl: './alumnos.component.html',
})
export class Alumnos implements OnInit {

  alumnos : Alumno[] = []
  error = ""
  constructor(private alumnoService:AlumnoService){}


  cargar(){
    this.alumnoService.listar().subscribe({
      next:(data) => (this.alumnos = data),
      error:() => (this.error = "No se pudo cargar la lista de alumnos")
    })
  }

  ngOnInit(): void {
    this.cargar()
  }

}
