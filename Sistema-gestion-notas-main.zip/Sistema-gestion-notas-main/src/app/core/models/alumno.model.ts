export interface Alumno {
  id?:              number;// puede tener un id o tampoco no puede
  codigo:          string;//alaanna
  nombres:         string;///ajajaa
  apellidos:       string;///ahaaa
  dni:             string;//289389893
  email:           string;
  fechaNacimiento: string;
  estado?:          string;// puede tener un estado tampoco no lo puede tener
}

export const DNI = /^[0-9]+([.][0-9]+)?$/


