import { ChangeDetectorRef, Component, inject, OnInit } from '@angular/core';
import { AlumnoService } from '../../core/services/alumno.service';
import { Alumno, DNI } from '../../core/models/alumno.model';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import Swal from 'sweetalert2';

@Component({
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  selector: 'app-alumnos',
  templateUrl: './alumnos.component.html',
})
export class Alumnos implements OnInit {
  alumnos: Alumno[] = [];
  error = '';

  // inyeccion de dependencia de forma actualizad
  private fb = inject(FormBuilder);

  mostrarForm = false;
  //editandoId:number | null = null

  formulario: Alumno = this.formVacio();

  editandoId: number | null = null;

  formularioBuilder = this.fb.group({
    codigo: [{ value: this.generarCodigo(), disabled: true }],
    dni: ['', [Validators.required, Validators.pattern(DNI)]],
    nombres: ['', Validators.required],
    apellidos: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    fechaNacimiento: [''],
  });

  constructor(
    private alumnoService: AlumnoService,
    private cdr: ChangeDetectorRef,
  ) {}

  invalido(campo: string): boolean {
    const campos = this.formularioBuilder.get(campo);
    return !!campos && campos.invalid && (campos.dirty || campos.touched);
  }

  abrirNuevo(): void {
    this.formularioBuilder.reset();
    this.editandoId = null;
    //this.formulario = this.formVacio()
    this.formularioBuilder.patchValue({ codigo: this.generarCodigo() });
    this.mostrarForm = true;
  }

  cerrarForm() {
    this.mostrarForm = false;
  }

  editar(alumno: Alumno) {
    this.formularioBuilder.reset();
    this.formularioBuilder.patchValue(alumno);
    this.editandoId = alumno.id ?? null;
    this.mostrarForm = true;
  }

  guardar(): void {
    // validamos que ek formulario este valido
    if (this.formularioBuilder.invalid) return;

    this.error = '';
    //const data:any = this.formularioBuilder.getRawValue()// todos su valores

    const valor: any = { ...this.formularioBuilder.getRawValue() };
    const accion = this.editandoId
      ? this.alumnoService.actualizar(this.editandoId, valor)
      : this.alumnoService.crear(valor);

    accion.subscribe({
      next: () => {
        this.cerrarForm();
        this.cargar();
      },
      error: (err) => (this.error = err?.error?.message ?? 'Ocurrio un error al guardar Alumno'),
    });
  }

  elminar(alumno: Alumno): void {
    if (!alumno.id) return;
    let alumnoid = alumno.id;

    this.alumnoService.eliminar(alumnoid).subscribe({
      next: () => {
        this.cargar();
      },
      error: (err) => (this.error = err?.error?.message ?? 'Ocurrio un error al guardar Alumno'),
    });

    /*
    ;*/
  }

  cargar() {
    this.alumnoService.listar().subscribe({
      next: (data) => {
        this.alumnos = data;
        this.cdr.detectChanges();
      },
      error: () => (this.error = 'No se pudo cargar la lista de alumnos'),
    });
  }

  ngOnInit(): void {
    this.cargar();
  }

  private formVacio(): Alumno {
    return { codigo: '', nombres: '', apellidos: '', dni: '', email: '', fechaNacimiento: '' };
  }

  // generador de codigos
  private generarCodigo(): string {
    const year = new Date().getFullYear(); // EL AÑO
    const correlative = Math.floor(10000 + Math.random() * 90000); // GENERA NUMERO ALAZAR
    return `AL-${year}-${correlative}`;
  }
}
